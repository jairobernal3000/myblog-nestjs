export enum PostCategory {
    'TECHNOLOGY',
    'LIFESTYLE',
    'CODING',
}
